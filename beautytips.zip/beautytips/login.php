<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Soukeerthy's | Login</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/font-awesome.css" rel="stylesheet">
      <link href="style.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body class="main" style="background-image: url(images/image.jpg);">
    <?php
            if(isset($_GET['login_failure'])){
                
                echo'<script>alert("Please Enter Valid Username/Password");</script>';
            }
            else if(isset($_GET['book_failure'])){
                echo'<script>alert("Please Login First");</script>';
            }
            else if(isset($_GET['already'])){
                echo'<script>alert("You already Have an account.Please Login.");</script>';
            }
        ?>
    <!--Navigation-->
        <nav class="navbar navbar-inverse navbar-fixed-top " style="box-shadow: 2px 2px 10px rgba(0,0,0,0.8);background: rgba(255,192,203,0.9);">
            <!--<nav class="navbar navbar-default">-->
        <div class="container-fluid">
                <!--Header Part/Top Part-->
        <header>
            <div class="row">
                <div class="col-md-3 logo" style="font-family: 'Lucida Calligraphy';">
                    <h2>Soukeerthy's</h2>
                    <h3>Beauty Studio</h3>
                </div>
                <div class="col-md-9">

                    <ul class="nav navbar-nav">
                        <br/>
                        <style type="text/css">a{color:white; font-size:19px;}</style>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">Why our Centre?</a></li>
                        <li><a href="service.php">Our Services</a> </li> 
                        <li><a href="contact.php">Contact Us</a> </li> 
                        <?php
                                session_start();  
                                if (isset($_SESSION['email'])){
                                    echo'<li><a style="color:black;" href="appoint.php">Appointment</a></li>
                                <li><a href="review.php">Review</a></li>
                                <li><a href="reg_val.php?logout">Logout</a></li>
                                ';
                            }
                            else{echo'<li><a href="login.php">Login</a></li>';}

                            ?>
                        
                    </ul>
                </div>
                    <!--Header Part/Top Part-->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        <span class="icon-bar"></span> 
                        </button>
                                
                    </div>
                </div>
            
            </div>
            </header>
        </div>
        </nav>
        <!--Navigation-->


    <div class="container" >
        <div class="login-box" style="margin-top:75px;">
        <img src="images/avatar.png" class="avatar">
            <h1>Login Here</h1>
                <form method="post" action="reg_val.php">
                    <div class="form-group">
                        <label>Enter Email</label>
                        <input type="email" name="email" class="form-control" placeholder="email" required="">
                    </div>
                    <div class="form-group">
                        <label>Enter Password</label>
                        <input type="password" name="password" class="form-control" placeholder="password" required="">
                        </div>
                        <br/>
                    <input type="submit" name="btn_login" value="Login"> 
                    <p>Not a User? <a href="register.php" style="color: red;font-size: 15px;">Register here</a></p>
                </form>
        </div>
    </div>

</body>
</html>