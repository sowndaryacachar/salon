<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Soukeerthy's | Register</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/font-awesome.css" rel="stylesheet">
      <link href="style.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>

<body style="background-image: url(images/register.jpg);">

    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 ">
                
                <div class="well" style="box-shadow: 2px 2px 10px rgba(0,0,0,0.8);
                    background: rgba(192,192,192,0.5); margin-top: -20px;">
                    <style type="text/css">label{color: black;} h1{color:orange;font-size:35px;}</style>
                    <h1>Register</h1>

                <form method="post" action="reg_val.php">
                    <div class="form-group">
                        <label>Enter Name</label>
                        <input type="text" name="name" class="form-control" placeholder="name" required="">
                    </div>

                    <div class="form-group">
                        <label>Enter Email</label>
                        <input type="email" name="email" class="form-control" placeholder="Email" required="">
                    </div>

                    <div class="form-group">
                        <label>Enter Phone</label>
                        <input type="number" name="phone" class="form-control" placeholder="phone" required="">
                    </div>

                    <div class="form-group">
                        <label>Enter City</label>
                        <input type="text" name="city" class="form-control" placeholder="city" required="">
                    </div>
                    <div class="form-group">
                        <label>Select Gender</label>
                        <br/>
                        <input type="radio" name="gender" value="male">Male
                        <input type="radio" name="gender" value="female">Female
                        <input type="radio" name="gender" value="other">other
                    </div>

                    <div class="form-group">
                        <label>Enter Password</label>
                        <input type="password" name="password" class="form-control" placeholder="password" required="">
                    </div>
                    <div class="form-group register">
                        <input type="submit" name="btn_register" class="btn btn-danger btn-block" value="Register Now">
                    </div>

                    
                </form>
                </div>
            </div>
        </div>
    </div>

    
    
    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
