-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2019 at 10:45 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `beauty`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `number` int(11) NOT NULL,
  `email` varchar(45) NOT NULL,
  `st_name` tinytext NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `treat` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`number`, `email`, `st_name`, `date`, `time`, `treat`) VALUES
(10, 'bhatkeerthana@gmail.com', 'stylist 5', '2019-07-31', '10:45:00', 'Melt into Moisture');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `emp_id` int(11) NOT NULL,
  `emp_name` tinytext NOT NULL,
  `emp_post` tinytext,
  `emp_salary` bigint(20) NOT NULL,
  `emp_email` varchar(64) DEFAULT NULL,
  `emp_accno` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `numb` int(11) NOT NULL,
  `email` varchar(64) NOT NULL,
  `review` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stylist`
--

CREATE TABLE `stylist` (
  `st_id` int(11) NOT NULL,
  `st_name` text NOT NULL,
  `treat` char(2) NOT NULL,
  `salary` bigint(20) NOT NULL,
  `st_email` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stylist`
--

INSERT INTO `stylist` (`st_id`, `st_name`, `treat`, `salary`, `st_email`) VALUES
(1, 'stylist 1', 'f', 10000, 'stylist_1@gmail.com'),
(2, 'stylist 2', 'f', 10000, 'stylist_2@gmail.com'),
(3, 'stylist 3', 'f', 15000, 'stylist_3@gmail.com'),
(4, 'stylist 4', 'h', 15000, 'stylist_4@gmail.com'),
(5, 'stylist 5', 'h', 15000, 'stylist_5@gmail.com'),
(6, 'stylist 6', 'h', 15000, 'stylist_6@gmail.com'),
(7, 'stylist 7', 's', 15000, 'stylist_7@gmail.com'),
(8, 'stylist 8', 's', 15000, 'stylist_8@gmail.com'),
(9, 'stylist 9', 's', 15000, 'stylist_9@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `treatments`
--

CREATE TABLE `treatments` (
  `treat_id` int(11) NOT NULL,
  `treat` char(2) NOT NULL,
  `full_treat` tinytext NOT NULL,
  `price` int(20) NOT NULL,
  `timemin` int(11) NOT NULL,
  `describe` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `treatments`
--

INSERT INTO `treatments` (`treat_id`, `treat`, `full_treat`, `price`, `timemin`, `describe`) VALUES
(1, 'f', 'HydraFacial MD', 20, 30, 'Only HydraFacial uses patented technology to cleanse, extract, and hydrate. HydraFacial super serums are made with nourishing ingredients that create an instantly gratifying glow.<br/>Uncover a new layer of skin with gentle exfoliation and relaxing resurfacing.Remove debris from pores with painless suction. Nourish with intense moisturizers that quench skin.Saturate the skin’s surface with antioxidants and peptides to maximize your glow.'),
(2, 'f', 'Deep Cleansing Facial', 85, 50, 'A customized, completely relaxing and cleansing facial skin treatment for all skin types, with skin analysis, steaming, cleaning of the pores, face, hand and arm massage with warm hand mitts, treatment mask, moisturizer, and recommendations for home care, leaving the skin clean, smooth, refreshed and glowing. with extractions.'),
(3, 'f', 'Sensitive Skin Facial', 110, 50, 'A sensitive skin facial which offers a cooling seaweed and organic silicon mask that provides instant radiance by hydrating, soothing, decongesting and minimizing redness. Ideal for those that generally have sensitive skin, redness, rosacea or reactive skin'),
(4, 'h', 'Melt into Moisture', 20, 30, 'Resurrect dry and parched tresses with a moisture protein treatment. The creme de la creme deep conditioning treatment, a quality moisture treatment can fix common hair woes such as lack of shine and split ends. Olaplex Hair Perfector No 3 is a popular repairing treatment that is massaged into the hair during a luxurious and relaxing service and can be added to the cost of your weekly blowout.'),
(5, 'h', 'Keratin Treatment', 85, 50, 'Want to fight the battle of frizzy hair and win? Keratin Complex has been a popular hair smoothing service for over ten years and can deliver smooth results for many weeks. Also known as the popular Brazilian Blowout, relaxers and keratin treatments can transform hair from curly to straight. The problem is they only last until your hair grows out, and then it is back to the salon for another application.<br/>Keratin treatments are ideal if you have curly or frizzy hair that just won’t quit and you want smooth results without the work of using flat irons and styling products at home.'),
(6, 'h', 'Scalp Treatment', 110, 50, 'If a dry and itchy scalp is one of your hair woes, an in salon scalp treatment can be a beneficial service that not only feels wonderful, it can substantially correct the scalp oil production and improve hair growth.'),
(7, 's', 'Microdermabrasion', 20, 30, 'Microdermabrasion works to remove age spots and lighter acne scars. The procedure is one of the favorite wrinkle treatments because it is performed quickly in a facial esthetics office. The physician uses a handheld instrument to spray small crystals onto the surface of the skin. The crystals exfoliate the skin layers, while using suction simultaneously to remove the crystals and dead skin cells. More than one microdermabrasion treatment may be needed for wrinkle removal and other skin treatments it provides.'),
(8, 's', 'Chemical Peels', 85, 50, 'Chemical peels, also called chemexfoliation or derma-peeling treatments, are cosmetic treatments performed on the face, typically used as an anti-aging solution to rejuvenate the skin. Chemical peels are used to correct skin irregularities in texture, such as fine lines, and color, such as spots caused by sun damage.<br/>These peels have varying strengths, characterized by the different kinds of acids used in the applied chemical solution. Chemical-peel solutions use three main acid ingredients to reach varying levels of intensity: alphahydroxy acid (AHA), trichloroacetic acid (TCA), and phenol.'),
(9, 's', 'Laser resurfacing', 110, 50, 'Laser resurfacing is a treatment to reduce facial wrinkles and skin irregularities, such as blemishes or acne scars.The technique directs short, concentrated pulsating beams of light at irregular skin, precisely removing skin layer by layer. This popular procedure is also called lasabrasion, laser peel, or laser vaporization.</p><p>Laser resurfacing is a procedure that uses a laser to improve the appearance of skin or treat minor facial flaws by removing layers of skin. The two most common types of resurfacing lasers are:');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(64) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `password` varchar(25) NOT NULL,
  `city` text NOT NULL,
  `gender` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `city`, `gender`) VALUES
(1, 'admin', 'admin@gmail.com', 0, 'admin', '', ''),
(2, 'Keerthana', 'bhatkeerthana@gmail.com', 8277057457, 'keerbha', 'Udupi', 'female'),
(3, 'kgjhskrs', 'arehgk@df.cvo', 4574545, '12354', 'dfsgg', 'male'),
(4, 'Keer', 'user@gmail.com', 124563, '120', 'dfsgg', 'other'),
(5, 'chaithra', 'chaithra@gamil.com', 5478964, '12356', 'sfdg', 'female'),
(6, 'Keer', 'keerthana.16cs029@sode-edu.in', 548574, '123655478', 'Udupi', 'female');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD UNIQUE KEY `number_UNIQUE` (`number`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`numb`);

--
-- Indexes for table `stylist`
--
ALTER TABLE `stylist`
  ADD PRIMARY KEY (`st_id`);

--
-- Indexes for table `treatments`
--
ALTER TABLE `treatments`
  ADD PRIMARY KEY (`treat_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password` (`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `numb` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stylist`
--
ALTER TABLE `stylist`
  MODIFY `st_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `treatments`
--
ALTER TABLE `treatments`
  MODIFY `treat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
