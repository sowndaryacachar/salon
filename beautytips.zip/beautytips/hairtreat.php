<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Beauty Centre | Service</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/font-awesome.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link href="style.css" rel="stylesheet">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    



        
        
</head>

<body class="bg" style="background-image: url(images/service6.jpg);">  
    <!--Navigation-->
        <nav class="navbar navbar-inverse navbar-fixed-top ">
            <!--<nav class="navbar navbar-default">-->
        <div class="headernav">
        <div class="container-fluid">
                <!--Header Part/Top Part-->
        <header>
            <div class="row">
                <div class="col-md-3 logo" style="font-family: 'Lucida Calligraphy';">
                    <h2>Soukeerthy's</h2>
                    <h3>Beauty Studio</h3>
                </div>
                <div class="col-md-9">

                    <ul class="nav navbar-nav">
                        <br/>
                        <style type="text/css">a{ font-size:19px;}</style>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">Why our Centre?</a></li>
                        <li class="dropdown">
                            <a href="service.php">Our services 
                              <i class="fa fa-caret-down"></i>
                            </a>
                            <div class="dropdown-content">
                              <a href="facetreat.php">Face Treatment</a>
                              <a href="hairtreat.php">Hair Treatment</a>
                              <a href="skintreat.php">Skin Treatment</a>
                            </div> 
                        </li> 
                        <li><a href="contact.php">Contact Us</a> </li> 
                        <?php
                                session_start();  
                                if (isset($_SESSION['email'])){
                                    echo'<li><a  href="appoint.php">Appointment</a></li>
                                <li><a href="review.php">Review</a></li>
                                <li><a href="reg_val.php?logout">Logout</a></li>
                                ';
                            }
                            else{echo'<li><a href="login.php">Login</a></li>';}

                            ?>
                    </ul>
                </div>
                    <!--Header Part/Top Part-->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        <span class="icon-bar"></span> 
                        </button>
                                
                    </div>
                </div>
            
            </div>
            </header>
        </div>
        </div>
        </nav>
        <!--Navigation-->
        <!--Services-->
        <section style="margin-top: 150px;">
            <div class="well service-box">
                <div class="row">
                    <h2>Melt into Moisture</h2>
                    <div class="col-md-4">
                        <img class="thumbnail img-responsive" src="images/moisture-treatment.jpg">
                    </div>
                    <div class="col-md-5">
                        
                        <p>Resurrect dry and parched tresses with a moisture protein treatment. The creme de la creme deep conditioning treatment, a quality moisture treatment can fix common hair woes such as lack of shine and split ends. Olaplex Hair Perfector No 3 is a popular repairing treatment that is massaged into the hair during a luxurious and relaxing service and can be added to the cost of your weekly blowout.
                        <br/>It’s best for parched, overprocessed, heat damaged and desperate hair that needs a little (or a lot) of love. Add a moisture treatment to your next coloring service and your hair will thank you.</p>
                    </div>
                    <div class="col-md-3">
                        <h3>Time:<p>30 minutes</p></h3>
                        <h3>Price:<p>$20</p></h3>
                        <a href="book.php?book&treat=moisture"><button class="button"><span>BOOK NOW</span></button></a>
                    </div>
                </div>
            </div>
            <div class="well service-box">
                <div class="row">
                    <h2>Keratin Treatment</h2>
                    <div class="col-md-4">
                        <img class="thumbnail img-responsive" src="images/keratin-treatment.jpg">
                    </div>
                    <div class="col-md-5">
                        
                        <p>Want to fight the battle of frizzy hair and win? Keratin Complex has been a popular hair smoothing service for over ten years and can deliver smooth results for many weeks. Also known as the popular Brazilian Blowout, relaxers and keratin treatments can transform hair from curly to straight. The problem is they only last until your hair grows out, and then it is back to the salon for another application.

                        <br/>Keratin treatments are ideal if you have curly or frizzy hair that just won’t quit and you want smooth results without the work of using flat irons and styling products at home.

                        <br/>There are two ways a keratin treatment can be applied to the hair so it’s important to know the difference between the two. A basic keratin smoothing treatment such as Goldwell’s Kerasilk penetrates into the cortex of your hair, promising shine and silky tresses for up to six months.</p>
                    </div>
                    <div class="col-md-3">
                        <h3>Time:<p>50 minutes</p></h3>
                        <h3>Price:<p>$85</p></h3>
                        <a href="book.php?book&treat=keratin"><button class="button"><span>BOOK NOW</span></button></a>
                    </div>
                </div>
            </div>

            <div class="well service-box">
                <div class="row">
                    <h2>Scalp Treatment</h2>
                    <div class="col-md-4">
                        <img class="thumbnail img-responsive" src="images/scalp-treatment.jpg">
                    </div>
                    <div class="col-md-5">
                        
                        <p>If a dry and itchy scalp is one of your hair woes, an in salon scalp treatment can be a beneficial service that not only feels wonderful, it can substantially correct the scalp oil production and improve hair growth.

                        <br/>Whether your fine hair is weighed down by an oily scalp or prone to flaky patches, a healthy scalp is essential if you want healthy hair. A scalp facial is a growing Japanese trend that is becoming widely popular due to the results of improved scalp skin. Brands such as Aveda and Phyto offer cocktails of complexes that exfoliate the scalp and remove buildup.It’s ideal for everyone. Scalp scrubs and serums are the new skin care for hair.</p>
                    </div>
                    <div class="col-md-3">
                        <h3>Time:<p>50 minutes</p></h3>
                        <h3>Price:<p>$110</p></h3>
                        <a href="book.php?book&treat=scalp"><button class="button"><span>BOOK NOW</span></button></a>
                    </div>
                </div>
            </div>
        </section>
        <!--Services-->
        <div class="container">
            
        </div>

    
        
    
    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
