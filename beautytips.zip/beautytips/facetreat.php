<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Beauty Centre | Service</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/font-awesome.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link href="style.css" rel="stylesheet">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    



        
        
</head>

<body class="bg" style="background-image: url(images/service6.jpg);">  
    <!--Navigation-->
        <nav class="navbar navbar-inverse navbar-fixed-top ">
            <!--<nav class="navbar navbar-default">-->
        <div class="headernav">
        <div class="container-fluid">
                <!--Header Part/Top Part-->
        <header>
            <div class="row">
                <div class="col-md-3 logo" style="font-family: 'Lucida Calligraphy';">
                    <h2>Soukeerthy's</h2>
                    <h3>Beauty Studio</h3>
                </div>
                <div class="col-md-9">

                    <ul class="nav navbar-nav">
                        <br/>
                        <style type="text/css">a{ font-size:19px;}</style>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">Why our Centre?</a></li>
                        <li class="dropdown">
                            <a href="service.php">Our services 
                              <i class="fa fa-caret-down"></i>
                            </a>
                            <div class="dropdown-content">
                              <a href="facetreat.php">Face Treatment</a>
                              <a href="hairtreat.php">Hair Treatment</a>
                              <a href="skintreat.php">Skin Treatment</a>
                            </div> 
                        </li> 
                        <li><a href="contact.php">Contact Us</a> </li> 
                        <?php
                                session_start();  
                                if (isset($_SESSION['email'])){
                                    echo'<li><a href="appoint.php">Appointment</a></li>
                                <li><a href="review.php">Review</a></li>
                                <li><a href="reg_val.php?logout">Logout</a></li>
                                ';
                            }
                            else{echo'<li><a href="login.php">Login</a></li>';}

                            ?>
                    </ul>
                </div>
                    <!--Header Part/Top Part-->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        <span class="icon-bar"></span> 
                        </button>
                                
                    </div>
                </div>
            
            </div>
            </header>
        </div>
        </div>
        </nav>
        <!--Navigation-->
        <!--Services-->
        <section style="margin-top: 150px;">
            <div class="well service-box">
                <div class="row">
                    <h2>HydraFacial MD</h2>
                    <div class="col-md-4">
                        <img class="thumbnail img-responsive" src="images/Hydrafacial2.jpg">
                    </div>
                    <div class="col-md-5">
                        
                        <p>Only HydraFacial uses patented technology to cleanse, extract, and hydrate. HydraFacial super serums are made with nourishing ingredients that create an instantly gratifying glow.</p>
                        <p>Uncover a new layer of skin with gentle exfoliation and relaxing resurfacing.</p>
                        <p>Remove debris from pores with painless suction. Nourish with intense moisturizers that quench skin.</p>
                        <p>Saturate the skin’s surface with antioxidants and peptides to maximize your glow.</p>
                    </div>
                    <div class="col-md-3">
                        <h3>Time:<p>30 minutes</p></h3>
                        <h3>Price:<p>$20</p></h3>
                        <a href="book.php?book&treat=hydra"><button class="button"><span>BOOK NOW</span></button></a>
                    </div>
                </div>
            </div>
            <div class="well service-box">
                <div class="row">
                    <h2>Deep Cleansing Facial</h2>
                    <div class="col-md-4">
                        <img class="thumbnail img-responsive" src="images/deepclens.jpg">
                    </div>
                    <div class="col-md-5">
                        
                        <p>A customized, completely relaxing and cleansing facial skin treatment for all skin types, with skin analysis, steaming, cleaning of the pores, face, hand and arm massage with warm hand mitts, treatment mask, moisturizer, and recommendations for home care, leaving the skin clean, smooth, refreshed and glowing. with extractions.</p>
                        <p>Deep cleansing facials are a classic type of facial, typically involving cleansing, steam, facial massage, facial mask, serum and moisturizer. Some therapists will perform extractions, removing blackheads and whiteheads. Deep cleansing facials are a good choice if your skin lacks moisture and is prone to breakouts.</p>
                    </div>
                    <div class="col-md-3">
                        <h3>Time:<p>50 minutes</p></h3>
                        <h3>Price:<p>$85</p></h3>
                        <a href="book.php?book&treat=deep"><button class="button" name="deep"><span>BOOK NOW</span></button></a>
                    </div>
                </div>
            </div>

            <div class="well service-box">
                <div class="row">
                    <h2>Sensitive Skin Facial</h2>
                    <div class="col-md-4">
                        <img class="thumbnail img-responsive" src="images/sensitive.jpg">
                    </div>
                    <div class="col-md-5">
                        
                        <p>A sensitive skin facial which offers a cooling seaweed and organic silicon mask that provides instant radiance by hydrating, soothing, decongesting and minimizing redness. Ideal for those that generally have sensitive skin, redness, rosacea or reactive skin</p>
                    </div>
                    <div class="col-md-3">
                        <h3>Time:<p>50 minutes</p></h3>
                        <h3>Price:<p>$110</p></h3>
                        <a href="book.php?treat=sensitive"><button class="button" name="sensitive"><span>BOOK NOW</span></button></a>
                    </div>
                </div>
            </div>
        </section>
        <!--Services-->
        <div class="container">
            
        </div>

    
        
    
    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
