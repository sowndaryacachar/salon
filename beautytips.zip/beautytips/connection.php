<?php
	$con = mysqli_connect('localhost','root','');//localhost,hostname or usernme,password
	mysqli_select_db($con,'beauty');//connection variable,database name
?>