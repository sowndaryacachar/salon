<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Soukeerthy's | Appointment View</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/font-awesome.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link href="style.css" rel="stylesheet">
	

</head>
<body>
    <?php
            if(isset($_GET['delete_success'])){
                
                echo'<script>alert("Cancelled");</script>';
            }
    ?>
	<!--Navigation-->

    <?php
            if(isset($_GET['update_success'])){
                
                echo'<script>alert("Updated Successfully");</script>';
            }
        ?>
        <nav class="navbar navbar-inverse navbar-fixed-top " style="box-shadow: 2px 2px 10px rgba(0,0,0,0.8);background: rgba(255,192,203,0.9);">
            <!--<nav class="navbar navbar-default">-->
        <div class="container-fluid">
                <!--Header Part/Top Part-->
        <header>
            <div class="row">
                <div class="col-md-3 logo" style="font-family: 'Lucida Calligraphy';">
                    <h2>Soukeerthy's</h2>
                    <h3>Beauty Studio</h3>
                </div>
                <div class="col-md-9">

                    <ul class="nav navbar-nav">
                        <br/>
                        <style type="text/css">a{color:white; font-size:19px;}</style>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">Why our Centre?</a></li>
                        <li><a href="service.php">Our Services</a> </li> 
                        <li><a href="contact.php">Contact Us</a> </li> 
                        <?php
                                session_start();  
                                if (isset($_SESSION['email'])){
                                    echo'<li><a style="color:black;" href="appoint.php">Appointment</a></li>
                                <li><a href="review.php">Review</a></li>
                                <li><a href="reg_val.php?logout">Logout</a></li>
                                ';
                            }
                            else{echo'<li><a href="login.php">Login</a></li>';}

                            ?>
                        
                    </ul>
                </div>
                    <!--Header Part/Top Part-->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        <span class="icon-bar"></span> 
                        </button>
                                
                    </div>
                </div>
            
            </div>
            </header>
        </div>
        </nav>
        <!--Navigation-->

        <div class="container" style="margin-top: 150px;">
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-bordered table-striped table-hover">
                            <tr>
                                <th>Stylist</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Treatment</th>
                                <th>Action</th>
                            </tr>

                            <?php
                                include("connection.php");
                                $email=$_SESSION['email'];
                                $query=mysqli_query($con,"SELECT * FROM `appointment` WHERE `email`='$email';") or die(mysqli_error($con));
                                while($row=mysqli_fetch_array($query))
                                {
                                    echo '<tr>
                                            <td>'.$row['st_name'].'</td>
                                            <td>'.$row['date'].'</td>
                                            <td>'.$row['time'].'</td>
                                            <td>'.$row['treat'].'</td>
                                            <td>
                                                <a href="edit_appoint.php?update&number='.$row['number'].'" class="btn btn-info btn-xs">Edit</a>
                                                <a href="reg_val.php?delete&number='.$row['number'].'" class="btn btn-danger btn-xs">Cancel</a>
                                            </td>
                                        </tr>';

                                }
                            ?>
                        </table>
                    </div>
                </div>
        </div>
        


        <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>


</body>
</html>