<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Soukeerthy's | Service</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/font-awesome.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link href="style.css" rel="stylesheet">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    



        
        
</head>

<body class="bg" style="background-image: url(images/service6.jpg);">  

    <?php
        if(isset($_GET['book_success'])){
                echo '<script>alert("Your Booking is Done!!Thank you")</script>';
            }
    ?>
    <!--Navigation-->
        <nav class="navbar navbar-inverse navbar-fixed-top " style="box-shadow: 2px 2px 10px rgba(0,0,0,0.8);background: rgba(255,192,203,0.9);">
            <!--<nav class="navbar navbar-default">-->
        <div class="container-fluid">
                <!--Header Part/Top Part-->
        <header>
            <div class="row">
                <div class="col-md-3 logo" style="font-family: 'Lucida Calligraphy';">
                    <h2>Soukeerthy's</h2>
                    <h3>Beauty Studio</h3>
                </div>
                <div class="col-md-9">

                    <ul class="nav navbar-nav">
                        <br/>
                        <style type="text/css">a{color:white; font-size:19px;}</style>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">Why our Centre?</a></li>
                        <li><a style="color: black;" href="service.php">Our Services</a> </li> 
                        <li><a href="contact.php">Contact Us</a> </li> 
                        <?php
                                session_start();  
                                if (isset($_SESSION['email'])){
                                    echo'<li><a " href="appoint.php">Appointment</a></li>
                                <li><a href="review.php">Review</a></li>
                                <li><a href="reg_val.php?logout">Logout</a></li>
                                ';
                            }
                            else{echo'<li><a href="login.php">Login</a></li>';}

                            ?>
                        
                    </ul>
                </div>
                    <!--Header Part/Top Part-->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        <span class="icon-bar"></span> 
                        </button>
                                
                    </div>
                </div>
            
            </div>
            </header>
        </div>
        </nav>
        <!--Navigation-->
        <!--Services-->
        <section>
            <div class="row" style="margin-top: 150px;margin-left: 50px;margin-right: 50px;">
                <div class="col-md-4">
                    <a href="facetreat.php"><div class="well service-box">
                        <img class="img-responsive img-circle" src="images/pic4.jpg">
                        <h2>Face Treatments</h2>
                                <p>HydraFacial MD</p>
                                <p>Deep Cleansing Facial</p>
                                <p>Sensitive Skin Facial</p>
                    </div></a>
                </div>
                <div class="col-md-4">
                    <a href="hairtreat.php"><div class="well service-box">
                        <img class="img-responsive img-circle" src="images/pic5.jpg">
                        <h2>Hair Treatments</h2>
                                <p>Melt into Moisture</p>
                                <p>Keratin Treatment</p>
                                <p>Scalp Treatment</p>
                    </div></a>
                </div>
                <div class="col-md-4">
                    <a href="skintreat.php"><div class="well service-box">
                        <img class="img-responsive img-circle" src="images/pic6.jpg">
                        <h2>Skin Care Treatments</h2>
                                <p>Microdermabrasion</p>
                                <p>Laser Resurfacing</p>
                                <p>Chemical Peels</p>
                    </div></a>
                </div>
            </div>
        </section>
        <!--Services-->
        <div class="container">
            
        </div>

    
        
    
    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
