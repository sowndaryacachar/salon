<?php
	include("connection.php");
	ob_start();
   session_start();
 
      if (isset($_POST['btn_login'])){
			
            $email = $_POST['email'];
			$pass = $_POST['password'];
			// email & password combination
		$query = mysqli_query($con,"SELECT * FROM `users` WHERE `email` = '$email' AND `password` = '$pass'") or die(mysqli_error($con));
		$count = mysqli_num_rows($query);
      
      	// If result matched $myusername and $mypassword, table row must be 1 row
		
      	if($count == 1) {         
         	
         	$_SESSION['valid'] = true;
            $_SESSION['timeout'] = time();
            $_SESSION['email'] = $email;
            if($email=='admin@gmail.com'&& $pass=='admin'){
              	header("location:admin/index.php");
            }
            else{
             	header("location:index.php?login_success");
            }
                  
                  
            }
            else {
               	header("location:login.php?login_failure");
                  
               }
            }


	if(isset($_POST['btn_register']))
	{
		$query=mysqli_query($con,"SELECT `email` FROM `users`;");
		while($row=mysqli_fetch_array($query))
		{
			if($row['email']==$_POST['email'])
			{
				header("location:login.php?already");
			}
		}
				$name = $_POST['name'];
				$email = $_POST['email'];
				$phone = $_POST['phone'];
				$city = $_POST['city'];
				$gender = $_POST['gender'];
				$password = $_POST['password'];	

				$query=mysqli_query($con,"INSERT INTO `users`(`name`, `email`, `phone`, `city`, `gender`, `password`) VALUES ('$name', '$email', '$phone', '$city', '$gender', '$password')") or die(mysqli_error($con));

				if($query)
				{
					header("location:index.php?reg_success");
					session_start();
					// Store Session Data
					$_SESSION['email']= $email;  // Initializing Session with value of PHP Variable
				}
				else
				{
					header("location:register.php");
				}
			
		

	}
	/*else if(isset($_POST['btn_login']))
	{
		$email = $_POST['email'];
		$pass = $_POST['password'];
			// email & password combination
		$query = mysqli_query($con,"SELECT * FROM `users` WHERE `email` = '$email' AND `password` = '$pass'") or die(mysqli_error($con));
		$count = mysqli_num_rows($query);
      
      	// If result matched $myusername and $mypassword, table row must be 1 row
		
      	if($count == 1) {         
         	
         	session_start();
			// Store Session Data
			$_SESSION['email']= $email;  // Initializing Session with value of PHP Variable
			echo '<h1>Welcome'.$_SESSION['email'].'</h1>';
			header("location:index.php?login_success");
      	}else {
      		header("location:login.php?login_failure");
      	}
	}*/
	else if(isset($_POST['btn_book']))
	{
		if(!(isset($_SESSION['email'])))
		{
			header("location:login.php?book_failure");
		}
		else{
			$email = $_SESSION['email'];
			$st_name=$_POST['st_name'];
			$date = $_POST['date'];
			$time = $_POST['time'];	
			if ($_GET['treat']=='hydra') {
				$treat='HydraFacial MD';
			}
			else if ($_GET['treat']=='deep') {
				$treat='Deep Cleansing Facial';
			}
			else if ($_GET['treat']=='sensitive') {
				$treat='Sensitive Skin Facial';
			}
			else if ($_GET['treat']=='moisture') {
				$treat='Melt into Moisture';
			}
			else if ($_GET['treat']=='keratin') {
				$treat='Keratin Treatment';
			}
			else if ($_GET['treat']=='scalp') {
				$treat='Scalp Treatment';
			}
			else if ($_GET['treat']=='micro') {
				$treat='Microdermabrasion';
			}
			else if ($_GET['treat']=='peels') {
				$treat='Chemical Peels';
			}
			else if ($_GET['treat']=='laser') {
				$treat='Laser resurfacing';
			}
			/*To check whether the stylist already ahve an appointment*/
			/*To check whether the customer have an appointment at the same time*/

			$query=mysqli_query($con,"INSERT INTO `appointment`(`email`, `st_name`, `date`, `time`, `treat`) VALUES ('$email','$st_name','$date','$time','$treat')") or die(mysqli_error($con));
			if($query)
			{
				header("location:service.php?book_success");
			}
			else
			{
				header("location:book.php?book_failure");
			}
		}
	}

	else if (isset($_GET['logout'])) {
		// remove all session variables
		session_unset(); 

		// destroy the session 
		session_destroy();
		header("location:index.php");
	}
	else if(isset($_GET['delete']))
	{
		$number =$_GET['number'];
		$query=mysqli_query($con,"DELETE FROM appointment WHERE number=$number") or die(mysqli_error($con));
		if($query)
		{
			header("location:appoint.php?delete_success");
		}	
		else
		{
			header("location:appoint.php?delete_error");
		}
	}
	else if(isset($_POST['btn_book_edit'])){
		$number =$_GET['number'];
		$date=$_POST['date'];
		$time=$_POST['time'];
		$query=mysqli_query($con,"UPDATE `beauty`.`appointment` SET `date` = '$date', `time` = '$time' WHERE (`number` = '9');
		") or die(mysqli_error($con));
	if($query)
		{
			header("location:appoint.php?update_success");
		}	
		else
		{
			header("location:appoint.php?update_error");
		}
	}
?>