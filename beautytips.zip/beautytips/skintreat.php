<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Soukeerthy's | Service</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/font-awesome.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link href="style.css" rel="stylesheet">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    



        
        
</head>

<body class="bg" style="background-image: url(images/service6.jpg);">  
    <!--Navigation-->
        <nav class="navbar navbar-inverse navbar-fixed-top ">
            <!--<nav class="navbar navbar-default">-->
        <div class="headernav">
        <div class="container-fluid">
                <!--Header Part/Top Part-->
        <header>
            <div class="row">
                <div class="col-md-3 logo" style="font-family: 'Lucida Calligraphy';">
                    <h2>Soukeerthy's</h2>
                    <h3>Beauty Studio</h3>
                </div>
                <div class="col-md-9">

                    <ul class="nav navbar-nav">
                        <br/>
                        <style type="text/css">a{ font-size:19px;}</style>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">Why our Centre?</a></li>
                        <li class="dropdown">
                            <a href="service.php">Our services 
                              <i class="fa fa-caret-down"></i>
                            </a>
                            <div class="dropdown-content">
                              <a href="facetreat.php">Face Treatment</a>
                              <a href="hairtreat.php">Hair Treatment</a>
                              <a href="skintreat.php">Skin Treatment</a>
                            </div> 
                        </li> 
                        <li><a href="contact.php">Contact Us</a> </li> 
                        <?php
                                session_start();  
                                if (isset($_SESSION['email'])){
                                    echo'<li><a style="href="appoint.php">Appointment</a></li>
                                <li><a href="review.php">Review</a></li>
                                <li><a href="reg_val.php?logout">Logout</a></li>
                                ';
                            }
                            else{echo'<li><a href="login.php">Login</a></li>';}

                            ?>
                    </ul>
                </div>
                    <!--Header Part/Top Part-->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        <span class="icon-bar"></span> 
                        </button>
                                
                    </div>
                </div>
            
            </div>
            </header>
        </div>
        </div>
        </nav>
        <!--Navigation-->
        <!--Services-->
        <section style="margin-top: 150px;">
            <div class="well service-box">
                <div class="row">
                    <h2>Microdermabrasion</h2>
                    <div class="col-md-4">
                        <img class="thumbnail img-responsive" src="images/micro.jpg">
                    </div>
                    <div class="col-md-5">
                        
                        <p>Microdermabrasion works to remove age spots and lighter acne scars. The procedure is one of the favorite wrinkle treatments because it is performed quickly in a facial esthetics office. The physician uses a handheld instrument to spray small crystals onto the surface of the skin. The crystals exfoliate the skin layers, while using suction simultaneously to remove the crystals and dead skin cells. More than one microdermabrasion treatment may be needed for wrinkle removal and other skin treatments it provides.</p>
                    </div>
                    <div class="col-md-3">
                        <h3>Time:<p>30 minutes</p></h3>
                        <h3>Price:<p>$20</p></h3>
                        <a href="book.php?book&treat=micro"><button class="button" name=""><span>BOOK NOW</span></button></a>
                    </div>
                </div>
            </div>
            

            <div class="well service-box">
                <div class="row">
                    <h2>Chemical Peels</h2>
                    <div class="col-md-4">
                        <img class="thumbnail img-responsive" src="images/peel.jpg">
                    </div>
                    <div class="col-md-5">
                        
                        <p>Chemical peels, also called chemexfoliation or derma-peeling treatments, are cosmetic treatments performed on the face, typically used as an anti-aging solution to rejuvenate the skin. Chemical peels are used to correct skin irregularities in texture, such as fine lines, and color, such as spots caused by sun damage.<br/>These peels have varying strengths, characterized by the different kinds of acids used in the applied chemical solution. Chemical-peel solutions use three main acid ingredients to reach varying levels of intensity: alphahydroxy acid (AHA), trichloroacetic acid (TCA), and phenol.</p>
                    </div>
                    <div class="col-md-3">
                        <h3>Time:<p>50 minutes</p></h3>
                        <h3>Price:<p>$110</p></h3>
                        <a href="book.php?book&treat=peels"><button class="button"><span>BOOK NOW</span></button></a>
                    </div>
                </div>
            </div>

            <div class="well service-box">
                <div class="row">
                    <h2>Laser resurfacing</h2>
                    <div class="col-md-4">
                        <img class="thumbnail img-responsive" src="images/laser-treatments.jpg">
                    </div>
                    <div class="col-md-5">
                        
                        <p>Laser resurfacing is a treatment to reduce facial wrinkles and skin irregularities, such as blemishes or acne scars.The technique directs short, concentrated pulsating beams of light at irregular skin, precisely removing skin layer by layer. This popular procedure is also called lasabrasion, laser peel, or laser vaporization.</p><p>Laser resurfacing is a procedure that uses a laser to improve the appearance of skin or treat minor facial flaws by removing layers of skin. The two most common types of resurfacing lasers are:

                        Carbon dioxide (CO2): This type of laser is used to treat wrinkles, scars, warts and other conditions.
                        Erbium: This type of laser is used to remove superficial and moderately deep lines and wrinkles on the face, hands, neck and chest. It causes fewer side effects than CO2 lasers.</p>

                    </div>
                    <div class="col-md-3">
                        <h3>Time:<p>50 minutes</p></h3>
                        <h3>Price:<p>$85</p></h3>
                        <a href="book.php?book&treat=laser"><button class="button"><span>BOOK NOW</span></button></a>
                    </div>
                </div>
            </div>
        </section>
        <!--Services-->
        <div class="container">
            
        </div>

    
        
    
    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
